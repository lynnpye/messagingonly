The three .cfg files (one for each game) are configured to replace the starting theme music for that game with a file located at:

	C:\Temp\themeogg.ogg

I have also included a file named themeogg.ogg for you test with. You can place it at the location described, or wherever you wish, but make sure whichever .cfg you use is pointing to the right location.